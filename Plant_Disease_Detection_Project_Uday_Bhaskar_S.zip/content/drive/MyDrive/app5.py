import streamlit as st
import tensorflow as tf
import numpy as np
import cv2
import os
from PIL import Image

# Load and preprocess the image
def model_predict(image_path):
    model = tf.keras.models.load_model(r"C:/Users/Karan S/Downloads/CNN_plant_disease_detection_model.keras")
    img = cv2.imread(image_path)  # read the file and convert into array
    H, W, C = 224, 224, 3
    img = cv2.resize(img, (H, W))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = np.array(img)
    img = img.astype("float32")
    img = img / 255.0  # rescaling
    img = img.reshape(1, H, W, C)  # reshaping

    prediction = np.argmax(model.predict(img), axis=-1)[0]

    return prediction

# Sidebar
st.sidebar.title("🌿 Plant Detection System for Sustainable Agriculture")
app_mode = st.sidebar.radio(
    "Navigation", ["Home", "Disease Recognition", "Plant Information", "About Project"]
)

# Home Page
if app_mode == "Home":
    st.markdown(
        """
        <div style="
            background: linear-gradient(135deg, #a5d6a7, #66bb6a); 
            padding: 30px; 
            border-radius: 15px; 
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.15); 
            text-align: center;">
            <h1 style="
                color: #2e7d32; 
                font-family: 'Trebuchet MS', sans-serif; 
                font-size: 42px; 
                margin: 0;">
                🌿 Welcome to the Plant Detection System
            </h1>
            <p style="
                color: #1b5e20; 
                font-family: 'Arial', sans-serif; 
                font-size: 20px; 
                margin-top: 15px;">
                Supporting Sustainable Agriculture through Technology
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    st.image(
        Image.open(r"C:/Users/Karan S/Downloads/Plant-Disease-analysis.jpg"),
        caption="Analyze Plant Health and Ensure Sustainability",
        use_container_width=True,
    )
    st.write(
        """
        ## 🌱 Overview
        The Plant Detection System leverages advanced AI to identify plant diseases and empower sustainable agriculture practices. Early disease detection ensures healthier crops and minimizes environmental impact.

        ### Features:
        - Disease Detection
        - Plant Health Information
        - Sustainable Agriculture Practices
        - Informative Insights into Common Plant Diseases
        """
    )

# Disease Recognition Page
elif app_mode == "Disease Recognition":
    st.markdown(
        """
        <div style="
            background-color: #f1f8e9; 
            padding: 20px; 
            border-radius: 15px; 
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1); 
            text-align: center;">
            <h1 style="
                color: #33691e; 
                font-family: 'Trebuchet MS', sans-serif; 
                font-size: 36px; 
                margin: 0;">
                Detect Plant Diseases with Ease
            </h1>
            <p style="
                color: #558b2f; 
                font-family: 'Arial', sans-serif; 
                font-size: 18px; 
                margin-top: 10px;">
                Upload an image to identify diseases and promote healthy crops.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    test_image = st.file_uploader("Choose an image", type=["jpg", "png", "jpeg"])

    if test_image is not None:
        save_path = os.path.join(os.getcwd(), test_image.name)
        with open(save_path, "wb") as f:
            f.write(test_image.getbuffer())



        if st.button("Detect Disease"):
            st.balloons()
            result_index = model_predict(save_path)

            class_name = [
                'Apple___Apple_scab', 'Apple___Black_rot', 'Apple___Cedar_apple_rust', 'Apple___healthy',
                'Blueberry___healthy', 'Cherry_(including_sour)___Powdery_mildew',
                'Cherry_(including_sour)___healthy', 'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot',
                'Corn_(maize)___Common_rust_', 'Corn_(maize)___Northern_Leaf_Blight', 'Corn_(maize)___healthy',
                'Grape___Black_rot', 'Grape___Esca_(Black_Measles)', 'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)',
                'Grape___healthy', 'Orange___Haunglongbing_(Citrus_greening)', 'Peach___Bacterial_spot',
                'Peach___healthy', 'Pepper,_bell___Bacterial_spot', 'Pepper,_bell___healthy',
                'Potato___Early_blight', 'Potato___Late_blight', 'Potato___healthy',
                'Raspberry___healthy', 'Soybean___healthy', 'Squash___Powdery_mildew',
                'Strawberry___Leaf_scorch', 'Strawberry___healthy', 'Tomato___Bacterial_spot',
                'Tomato___Early_blight', 'Tomato___Late_blight', 'Tomato___Leaf_Mold',
                'Tomato___Septoria_leaf_spot', 'Tomato___Spider_mites Two-spotted_spider_mite',
                'Tomato___Target_Spot', 'Tomato___Tomato_Yellow_Leaf_Curl_Virus', 'Tomato___Tomato_mosaic_virus',
                'Tomato___healthy'
            ]

            st.success(f"The model predicts: {class_name[result_index]}")

# Plant Information Page
elif app_mode == "Plant Information":
    st.markdown(
        """
        <div style="
            background-color: #e8f5e9; 
            padding: 20px; 
            border-radius: 15px; 
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1); 
            text-align: center;">
            <h1 style="
                color: #2e7d32; 
                font-family: 'Trebuchet MS', sans-serif; 
                font-size: 36px; 
                margin: 0;">
                🌳 Learn About Plants
            </h1>
        </div>
        """,
        unsafe_allow_html=True
    )
    st.write(
        """
        ## 🌱 Importance of Plants
        - Plants are vital for life on Earth, providing oxygen, food, and habitats.
        - Healthy plants ensure biodiversity and ecological balance.

        ## 🌼 Common Plant Diseases
        - Fungal diseases like Powdery Mildew and Rust
        - Bacterial diseases such as Bacterial Blight
        - Viral infections impacting crop health and yield

        ## 🌿 Tips for Plant Health
        - Regular monitoring of plant health
        - Using natural fertilizers
        - Practicing crop rotation
        """
    )

# About Project Page
elif app_mode == "About Project":
    st.markdown(
        """
        <div style="
            background-color: #c8e6c9; 
            padding: 20px; 
            border-radius: 15px; 
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1); 
            text-align: center;">
            <h1 style="
                color: #1b5e20; 
                font-family: 'Trebuchet MS', sans-serif; 
                font-size: 36px; 
                margin: 0;">
                About the Project
            </h1>
        </div>
        """,
        unsafe_allow_html=True
    )
    st.write(
        """
        ## 🌟 Project Overview
        The Plant Detection System for Sustainable Agriculture is designed to aid farmers and agricultural experts in identifying plant diseases efficiently and accurately.

        ### Applications:
        - Early Disease Detection
        - Sustainable Farming Practices
        - Educational Tool for Agricultural Studies

        ### Vision:
        - To empower farmers with technology
        - To promote eco-friendly farming methods
        - To enhance global food security
        """
    )
